1. terraform workspace list - It will list out all the workspaces

2. terraform workspace new prod - It create a workspace and swtich to prod. Similary you can create 

 terraform workspace new dev

3.  terraform workspace show - It will show the current workspace you are in

4. terraform apply -var-file dev.tfvars

5. Switch workspace by - terraform workspace select prod